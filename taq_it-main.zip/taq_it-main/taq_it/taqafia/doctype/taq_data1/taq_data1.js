// Copyright (c) 2025, ahmeed and contributors
// For license information, please see license.txt

// frappe.ui.form.on("taq_data1", {
// 	refresh(frm) {

// 	},
// });
