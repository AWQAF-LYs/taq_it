// Copyright (c) 2025, ahmeed and contributors
// For license information, please see license.txt

// frappe.ui.form.on("lagna_taq", {
// 	refresh(frm) {

// 	},
// });
